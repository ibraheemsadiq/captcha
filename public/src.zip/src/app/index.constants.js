/* global malarkey:false, moment:false */
(function() {
  'use strict';

  angular
    .module('public')
    .constant('malarkey', malarkey)
    .constant('moment', moment);

})();
